# Easyplot toolbox
EasyplotPy is a software being developed by the research group headed by professor Wanderlei Malaquias Pereira Junior in Faculty of Engineering at Federal University of Catalão (UFCAT). EasyplotPy algorithm provide an easy workflow to assemble charts and save figures. The framework was developed in Python language.

# Version

### 2.0.0

_feat:_  
- scatter + line chart
  
_improvement:_   

_bug:_   

_doc:_  

_config:_ 
