# Easyplot toolbox
EasyplotPy is a software being developed by the research group headed by professor Wanderlei Malaquias Pereira Junior in Faculty of Engineering at Federal University of Catalão (UFCAT). EasyplotPy algorithm provide an easy workflow to assemble charts and save figures. The framework was developed in Python language.

# Version
### 1.1.0

_feat:_  
  
_improvement:_  
- scatter_chart new plot   

_bug:_  
  
_doc:_  
- line_chart new doc  
- histogram_chart new doc  
- scatter_chart new doc   

_config:_   

### 1.0.0

_feat:_
- histogram_chart: This function shows a boxplot and histogram in a single chart.  
- scatter_chart: This function shows a scatter plot in single chart.
- scatter_line_plot: This function shows a scatter and line chart.

_improvement:  
_bug:_  
_doc:_  
_config:_

### 0.0.0

_feat:_
- line_chart: This function shows a multiple lines in single chart     

_improvement:_  
_bug:_  
_doc:_  
_config:_  
