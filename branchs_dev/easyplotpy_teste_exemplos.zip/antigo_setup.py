# from setuptools import setup

# with open("readme2.md", "r") as fh:
# 			long_description = fh.read()

# setup(
# 				name = pyproject_toml['project']['name'],
# 				long_description=long_description,
# 				long_description_content_type="text/markdown",
# 				version = '0.0.0',
# 				url = 'https://wmpjrufg.github.io/EASYPLOTPY/',
# 				license = 'MIT',
# 				authors = ['Wanderlei Malaquias Pereira Junior', 'Sergio Francisco da Silva', 'Nilson Jorge Leão Junior', 'Mateus Pereira da Silva', 'Luiz Henrique Rézio'],
# 				author_email = 'wanderlei_junior@ufcat.edu.br',
# 				maintainers = ['Wanderlei Malaquias Pereira Junior'],
# 				install_requires = ["matplotlib", "seaborn", "squarify", "joypy"],
# 				classifiers = [
# 												'Development Status :: 4 - Beta',
# 												'Topic :: Education',
# 												'Topic :: Multimedia :: Graphics',
# 												'License :: OSI Approved :: MIT License',
# 												'Framework :: Matplotlib', 
# 												'Programming Language :: Python'
# 											],
#     	)

# # pip install setuptools
# # python setup.py bdist_wheel
# # pip install twine
# # twine upload --repository testpypi dist/*
# # twine upload dist/*

# usando o arquivo pyproject.toml
# poetry build
# poetry publish